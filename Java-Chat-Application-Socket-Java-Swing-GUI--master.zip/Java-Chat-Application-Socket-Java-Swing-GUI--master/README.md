# Java-Chat-Application-Socket-Java-Swing-GUI-
Socket based chat application with a chat client and a chat server. With swing GUI and message  encryption in SHA1

![alt text](https://i.ibb.co/mJqYZtV/Screenshot-2020-06-24-at-19-44-29.png)
