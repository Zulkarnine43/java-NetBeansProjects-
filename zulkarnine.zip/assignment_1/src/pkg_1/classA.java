package pkg_1;
/**
 *
 * @author Zulkar Nine
 */
public class classA {
  
 public void displayA(String name, int id){
     
      System.out.println("name is="+name+"\n");           
      System.out.println("id is="+id+"\n");                        
}
}
